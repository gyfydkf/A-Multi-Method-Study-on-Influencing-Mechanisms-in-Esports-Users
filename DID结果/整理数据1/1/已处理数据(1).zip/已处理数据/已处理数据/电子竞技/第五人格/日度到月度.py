import pandas as pd
import matplotlib.pyplot as plt

# 读取数据
file_path = '第五人格每日评论.csv'  # 替换成你的路径
df = pd.read_csv(file_path, parse_dates=['日期'])

# 确保数据按日期排序
df = df.sort_values('日期')

# 方法一：按月取平均值（日均用户规模）
monthly_avg = df.resample('M', on='日期').mean().reset_index()
monthly_avg.rename(columns={'用户规模': '月均用户规模'}, inplace=True)

# 方法二：按月求总和（当月总用户量）
monthly_sum = df.resample('M', on='日期').sum().reset_index()
monthly_sum.rename(columns={'用户规模': '月总用户规模'}, inplace=True)

# 保存结果
monthly_avg.to_csv('月均用户规模.csv', index=False, encoding='utf-8-sig')
monthly_sum.to_csv('月总用户规模.csv', index=False, encoding='utf-8-sig')

print("月度数据已保存为：月均用户规模.csv 和 月总用户规模.csv")

# 可视化
plt.figure(figsize=(12, 6))
plt.plot(monthly_avg['日期'], monthly_avg['月均用户规模'], marker='o', label='月均用户规模')
plt.plot(monthly_sum['日期'], monthly_sum['月总用户规模'], marker='s', label='月总用户规模', alpha=0.7)
plt.legend()
plt.title("日度数据汇总为月度数据")
plt.xlabel("月份")
plt.ylabel("用户规模")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
